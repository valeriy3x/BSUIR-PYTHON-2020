from setuptools import setup, find_packages

setup(
    name='lab2_kurbyko',
    version='1.1',
    packages=find_packages(),
    url='',
    license='MIT',
    author='Kurbyko Valery',
    author_email='valeriykurbyko@gmail.com',
    description='lab2'
)
